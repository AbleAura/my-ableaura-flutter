class MainSkill {
  final String name;
  final List<String> subSkills;

  MainSkill({
    required this.name,
    required this.subSkills,
  });
}